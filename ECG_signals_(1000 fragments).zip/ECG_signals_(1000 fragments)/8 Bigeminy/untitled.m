% Load data from abc.mat
data = load('abc.mat');  % Load the .mat file

% Display all available fields (variables) in the .mat file
disp('Variables in abc.mat:');
disp(fieldnames(data));

% Manually define the sampling frequency since it's not in the .mat file
fs = 1000;  % Use default fs = 1000 Hz, or set to the correct value
disp('Sampling frequency not found in abc.mat, using default fs = 1000 Hz');

% Assume 'val' is the ECG signal in the .mat file
val = data.val;   % ECG signal

% Plot Original ECG Signal
figure;
plot(val);
xlabel('Time (s)');
ylabel('Amplitude');
title('Original ECG Signal');

% Filter ECG signal to remove low-frequency noise
ecg_filtered = highpass(val, 0.5, fs);

% Apply Hamming window
windowed_signal = ecg_filtered .* hamming(length(ecg_filtered));

% Perform FFT
N = length(windowed_signal);
fft_signal = fft(windowed_signal, N);

% Frequency axis
f = (0:N-1)*(fs/N);

% Calculate magnitude spectrum
magnitude_spectrum = abs(fft_signal/N);

% Plot magnitude spectrum
figure;
plot(f, magnitude_spectrum);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Magnitude Spectrum of ECG Signal');

% Analyze the spectrum: find peaks
threshold = 0.1 * max(magnitude_spectrum); % Define your threshold
f_range = (f >= 0 & f <= 50); % Focus on 0 to 50 Hz range

% Find peaks in the magnitude spectrum within the specified frequency range
[peaks, locations] = findpeaks(magnitude_spectrum(f_range), f(f_range));

% Ensure threshold is a scalar and find significant peaks
if ~isempty(peaks)
    significant_peaks = peaks(peaks > threshold);
    significant_frequencies = locations(peaks > threshold);
else
    significant_peaks = [];
    significant_frequencies = [];
end

% Display significant frequencies
if ~isempty(significant_frequencies)
    disp('Significant Frequencies:');
    disp(significant_frequencies);
else
    disp('No significant frequencies found above the threshold.');
end
